/* global malarkey:false, moment:false */
(function() {
  'use strict';

  angular
    .module('ui')
    .constant('malarkey', malarkey)
    .constant('moment', moment);

})();
