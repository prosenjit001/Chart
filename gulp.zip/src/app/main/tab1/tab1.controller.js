(function() {
    "use strict";

    angular.module("ui").controller("Tab1Controller", Tab1Controller);

    function Tab1Controller(
        $scope,
        $timeout,
        $mdDialog,
        $mdMedia,
        chart,
        table,
        ChartService,
        SharedService,
        $rootScope
    ) {
        var vm = this;

        vm.chartBind = chartBind;
        vm.showZoom = getPopup;
        vm.Navigate = navigate;
        vm.search = search;

        var category = [],
            mod1 = [],
            mod2 = [],
            data = [];

        var chartIds = "";
        vm.chart1Loader = true;
        vm.chart2Loader = true;
        vm.chart3Loader = true;
        vm.chart1 = true;
        vm.chart2 = true;
        vm.chart3 = true;

        function navigate(type) {
            if (type == 1) {
                $rootScope.$emit("CallParentMethod", {});
            }
        }

       

        vm.chartBind(2, 0);

        function chartBind(type, param) {
            var stratDt = "",
                endDt = "",
                txt1 = 0,
                txt2 = 0,
                txt3 = 0;

            if (vm.Filter !== undefined) {
                stratDt = vm.Filter.startDate;
                endDt = vm.Filter.endDate;
                txt1 = vm.Filter.txt1;
                txt2 = vm.Filter.txt2;
                txt3 = vm.Filter.txt3;
            }

            if (type == 2) vm.chart1Loader = true;

            var param = {
                Type: type,
                Param1: param,
                FromDate: stratDt,
                EndDate: endDt,
                CenterId: txt1,
                EmployeeId: txt2,
                TranTypeId: txt3,
                pageNo: 1,
                pageSize: 10
            };

            ChartService.GetChart(param).then(function(response) {
                (category = []), (data = []), (mod1 = []), (mod2 = []);

                if (type == 2) {
                    vm.chart1Loader = false;
                    vm.chart2Loader = false;
                    vm.chart3Loader = false;
                    vm.chart4Loader = false;
                }

                angular.forEach(response.data, function(value, key) {
                    category.push(value.displayText);
                    mod1.push({ y: value.value, name: value.displayText });
                });

                data.push({ colorByPoint: true, name: "", data: mod1 });
                if (type == 2) vm.chartZoom1 = { data: data, category: category };

                if (type == 2) chartIds = "tab1Chart1";

                for (var i = 1; i < 5; i++) {
                    var chartTypes = "";
                    if (i == 2 || i == 3) chartTypes = "column";
                    else chartTypes = "pie";

                    chart.ChartBind(
                        chartTypes,
                        "tab1Chart" + i,
                        "",
                        true,
                        data,
                        category,
                        false,
                        true,
                        type,
                        0
                    );
                }
            });
        }

        //Popup
        function getPopup(type, ev) {
            vm.customFullscreen = false;
            $mdDialog.show({
                skipHide: true,
                clickOutsideToClose: false,
                parent: angular.element(document.body),
                targetEvent: ev,
                controller: function($scope, chart, $timeout) {
                    $scope.type = type;
                    $timeout(function() {
                        if (type == 1)
                            chart.ChartBind(
                                "pie",
                                "gchart",
                                "",
                                true,
                                vm.chartZoom1.data,
                                vm.chartZoom1.category
                            );
                    }, 100);

                    $scope.Cancel = function() {
                        $mdDialog.hide();
                    };

                    $scope.closeDialog = function($scope) {
                        $mdDialog.hide();
                    };
                },
                templateUrl: "app/components/dialog/zoom.html"
            });
        }

        $scope.$on("onSearch", function(event, obj) {
            if (obj.id !== 4) {
                vm.chartBind(obj.id, obj.data.name);
                if (obj.id == 2) {
                    vm.centerId = obj.data.name;
                    vm.empHeader = obj.data.name;
                    vm.trenPageNo = 1;
                    vm.tranPageSize = 5;
                    vm.empPageNo = 1;
                    vm.empPageSize = 10;
                } else if (obj.id == 3) {
                    vm.tranTypeId = obj.data.name;
                    vm.empHeader = obj.data.name;
                    vm.empPageNo = 1;
                    vm.empPageSize = 10;
                }
            } else {
                //po[pup]
            }
        });

        $scope.$on("onSearch_Main", function(event, obj) {
            vm.search(obj.myMsg);
        });

        $scope.$on("onClear", function(event, obj) {
            vm.search(obj.myMsg);
        });

        function search(Filter) {
            vm.Filter = Filter;
            var fd1, fd2;

            if (vm.Filter.startDate !== undefined && vm.Filter.startDate !== "") {
                var fd = new Date(vm.Filter.startDate);
                fd1 = new Date(fd.getFullYear(), fd.getMonth() + 1, fd.getDate());
                vm.Filter.startDate =
                    fd.getFullYear() +
                    "-" +
                    ((fd.getMonth() + 1).toString().length == 1 ?
                        "0" + (fd.getMonth() + 1) :
                        fd.getMonth() + 1) +
                    "-" +
                    (fd.getDate().toString().length == 1 ?
                        "0" + fd.getDate() :
                        fd.getDate());
            } else {
                vm.Filter.startDate = "";
            }
            if (vm.Filter.endDate !== undefined && vm.Filter.endDate !== "") {
                var fd = new Date(vm.Filter.endDate);
                fd2 = new Date(fd.getFullYear(), fd.getMonth() + 1, fd.getDate());
                vm.Filter.endDate =
                    fd.getFullYear() +
                    "-" +
                    ((fd.getMonth() + 1).toString().length == 1 ?
                        "0" + (fd.getMonth() + 1) :
                        fd.getMonth() + 1) +
                    "-" +
                    (fd.getDate().toString().length == 1 ?
                        "0" + fd.getDate() :
                        fd.getDate());
            } else {
                vm.Filter.endDate = "";
            }

            if (vm.Filter.txt1 == undefined && vm.Filter.txt1 == "") {
                vm.Filter.txt1 = 0;
            }
            if (vm.Filter.txt2 == undefined && vm.Filter.txt2 == "") {
                vm.Filter.txt2 = 0;
            }
            if (vm.Filter.txt3 == undefined && vm.Filter.txt3 == "") {
                vm.Filter.txt3 = 0;
            }

            vm.chartBind(1, 0);
        }

        function getInterval() {
            $timeout(function() {
                vm.chartBind(2, 0);
                if (vm.interval == 1) getInterval();
            }, 5000);
        }
        $scope.$on("interval", function(event, obj) {
            vm.interval = obj.msg;

            if (vm.interval == 1) {
                getInterval();
            }
        });
    }
})();