(function() {
    "use strict";

    angular.module("ui").controller("ChartController", ChartController);

    function ChartController(
        $scope,
        $timeout,
        $mdDialog,
        $mdMedia,
        chart,
        table,
        ChartService
    ) {
        var vm = this;

        vm.chartBind = chartBind;
        vm.getTable = getTable;
        vm.showTable = showTable;
        vm.showZoom = getPopup;
        vm.search = search;
        vm.Next = Next;
        vm.Prev = Prev;

        //Variable
        var category = [],
            mod1 = [],
            mod2 = [],
            data = [];
        vm.empHeader = 0;
        vm.empPageNo = 1;
        vm.trenPageNo = 1;
        vm.empPageSize = 10;
        vm.tranPageSize = 5;
        vm.empTotalPage = 0;
        vm.trenTotalPage = 0;
        vm.empNoPosition = "";
        vm.tranNoPosition = "";
        vm.centerId = 0;
        vm.tranTypeId = 0;
        //End

        //Page load call

        vm.chartBind(1, 0);
        //vm.chartBind(2, 1);
        //vm.chartBind(3, 0);
        //End

        var chartIds = "";
        vm.chart1Loader = true;
        vm.chart2Loader = true;
        vm.chart3Loader = true;
        vm.chart1 = true;
        vm.chart2 = true;
        vm.chart3 = true;

        //Chart Bind
        function chartBind(type, param) {
            var stratDt = "",
                endDt = "",
                txt1 = 0,
                txt2 = 0,
                txt3 = 0;
            if (vm.Filter !== undefined) {
                stratDt = vm.Filter.startDate;
                endDt = vm.Filter.endDate;
                txt1 = vm.Filter.txt1.CenterID;
                txt2 = vm.Filter.txt2;
                txt3 = vm.Filter.txt3;
            }

            if (type == 1) vm.chart1Loader = true;
            else if (type == 2) vm.chart2Loader = true;
            else if (type == 3) vm.chart3Loader = true;

            var param = {
                Type: type,
                Param1: param,
                FromDate: stratDt,
                EndDate: endDt,
                CenterId: txt1,
                EmployeeId: txt2,
                TranTypeId: txt3,
                pageNo: type == 2 ? vm.trenPageNo : vm.empPageNo,
                pageSize: type == 2 ? vm.tranPageSize : vm.empPageSize
            };
            ChartService.GetChart(param).then(function(response) {
                (category = []), (data = []), (mod1 = []), (mod2 = []);

                if (type == 1) {
                    vm.chart1Loader = false;
                    vm.centerId = response.data[0].text;
                    vm.chartBind(2, response.data[0].text);
                } else if (type == 2) {
                    vm.tranTypeId = response.data[0].text;
                    vm.empHeader = response.data[0].text;
                    vm.chartBind(3, response.data[0].text);
                    vm.chart2Loader = false;
                    vm.trenTotalPage = Math.ceil(
                        response.data[0].totalRows / vm.tranPageSize
                    );
                    vm.tranNoPosition = vm.trenPageNo + "/" + vm.trenTotalPage;
                } else if (type == 3) {
                    vm.chart3Loader = false;
                    vm.empTotalPage = Math.ceil(
                        response.data[0].totalRows / vm.empPageSize
                    );
                    vm.empNoPosition = vm.empPageNo + "/" + vm.empTotalPage;
                }

                getTable(response.data, type);

                angular.forEach(response.data, function(value, key) {
                    category.push(value.displayText);
                    mod1.push({ y: value.value, name: value.text });
                });

                data.push({ colorByPoint: true, name: "Emirates", data: mod1 });

                if (type == 1) vm.chartZoom1 = { data: data, category: category };
                else if (type == 2) vm.chartZoom2 = { data: data, category: category };
                else if (type == 3) vm.chartZoom3 = { data: data, category: category };

                if (type == 1) chartIds = "chart1";
                else if (type == 2) chartIds = "chart2";
                else if (type == 3) chartIds = "chart3";

                chart.ChartBind(
                    "column",
                    chartIds,
                    "",
                    false,
                    data,
                    category,
                    false,
                    true,
                    type,
                    0
                );
            });
        }

        //Table Bind
        function getTable(mod, type) {
            var jsonColumn = "";
            var tableColumn = "";
            if (type == 1) {
                jsonColumn = "text,value";
                tableColumn = "Category,Count";
                vm.tbl1 = table.TableBind(jsonColumn, tableColumn, mod, false);
            } else if (type == 2) {
                jsonColumn = "text,value";
                tableColumn = "Category,Count";
                vm.tbl2 = table.TableBind(jsonColumn, tableColumn, mod, false);
            } else if (type == 3) {
                jsonColumn = "text,value";
                tableColumn = "Category,Count";
                vm.tbl3 = table.TableBind(jsonColumn, tableColumn, mod, false);
            }
        }

        function showTable(type) {
            $timeout(function() {
                if (type == 1) {
                    if (vm.chart1 == false) vm.chart1 = true;
                    else vm.chart1 = false;
                } else if (type == 2) {
                    if (vm.chart2 == false) vm.chart2 = true;
                    else vm.chart2 = false;
                } else if (type == 3) {
                    if (vm.chart3 == false) vm.chart3 = true;
                    else vm.chart3 = false;
                }
            }, 10);
        }

        //Popup
        function getPopup(type, ev) {
            vm.customFullscreen = false;

            $mdDialog.show({
                skipHide: true,
                clickOutsideToClose: false,
                parent: angular.element(document.body),
                targetEvent: ev,
                controller: function($scope, chart, $timeout) {
                    $scope.type = type;
                    $timeout(function() {
                        if (type == 1)
                            chart.ChartBind(
                                "column",
                                "gchart",
                                "",
                                false,
                                vm.chartZoom1.data,
                                vm.chartZoom1.category
                            );
                        if (type == 2)
                            chart.ChartBind(
                                "column",
                                "gchart",
                                "",
                                false,
                                vm.chartZoom2.data,
                                vm.chartZoom2.category
                            );
                        if (type == 3)
                            chart.ChartBind(
                                "column",
                                "gchart",
                                "",
                                false,
                                vm.chartZoom3.data,
                                vm.chartZoom3.category
                            );
                    }, 100);
                    $scope.Cancel = function() {
                        $mdDialog.hide();
                    };

                    $scope.closeDialog = function($scope) {
                        $mdDialog.hide();
                    };

                    $scope.Refresh = function() {
                        $timeout(function() {
                            if (type == 1)
                                chart.ChartBind(
                                    "column",
                                    "gchart",
                                    "",
                                    false,
                                    vm.chartZoom1.data,
                                    vm.chartZoom1.category
                                );
                            if (type == 2)
                                chart.ChartBind(
                                    "column",
                                    "gchart",
                                    "",
                                    false,
                                    vm.chartZoom2.data,
                                    vm.chartZoom2.category
                                );
                            if (type == 3)
                                chart.ChartBind(
                                    "column",
                                    "gchart",
                                    "",
                                    false,
                                    vm.chartZoom3.data,
                                    vm.chartZoom3.category
                                );
                        }, 100);
                    };
                },
                templateUrl: "app/components/dialog/zoom.html"
            });
        }

        //Broadcast data

        function getInterval() {
            $timeout(function() {
                vm.chartBind(1, 0);
                if (vm.interval == 1) getInterval();
            }, 5000);
        }
        $scope.$on("interval", function(event, obj) {
            vm.interval = obj.msg;

            if (vm.interval == 1) {
                getInterval();
            }
        });

        $scope.$on("onSearch", function(event, obj, ev) {
            if (obj.id !== 4) {
                vm.chartBind(obj.id, obj.data.name);
                if (obj.id == 2) {
                    vm.centerId = obj.data.name;
                    vm.empHeader = obj.data.name;
                    vm.trenPageNo = 1;
                    vm.tranPageSize = 5;
                    vm.empPageNo = 1;
                    vm.empPageSize = 10;
                } else if (obj.id == 3) {
                    vm.tranTypeId = obj.data.name;
                    vm.empHeader = obj.data.name;
                    vm.empPageNo = 1;
                    vm.empPageSize = 10;
                }
            } else {
                alert(obj.data.name);
                $mdDialog.show({
                    skipHide: true,
                    clickOutsideToClose: false,
                    parent: angular.element(document.body),
                    targetEvent: ev,
                    controller: function($scope, chart, $timeout) {
                        $scope.id = obj.id;

                        $scope.Cancel = function() {
                            $mdDialog.hide();
                        };

                        $scope.closeDialog = function($scope) {
                            $mdDialog.hide();
                        };
                    },
                    templateUrl: "app/components/dialog/zoom.html"
                });
            }
        });

        $scope.$on("onSearch_Main", function(event, obj) {
            vm.search(obj.myMsg);
        });

        $scope.$on("onClear", function(event, obj) {
            vm.search(obj.myMsg);
        });

        function search(Filter) {
            vm.Filter = Filter;
            var fd1, fd2;

            if (vm.Filter.startDate !== undefined && vm.Filter.startDate !== "") {
                var fd = new Date(vm.Filter.startDate);
                fd1 = new Date(fd.getFullYear(), fd.getMonth() + 1, fd.getDate());
                vm.Filter.startDate =
                    fd.getFullYear() +
                    "-" +
                    ((fd.getMonth() + 1).toString().length == 1 ?
                        "0" + (fd.getMonth() + 1) :
                        fd.getMonth() + 1) +
                    "-" +
                    (fd.getDate().toString().length == 1 ?
                        "0" + fd.getDate() :
                        fd.getDate());
            } else {
                vm.Filter.startDate = "";
            }
            if (vm.Filter.endDate !== undefined && vm.Filter.endDate !== "") {
                var fd = new Date(vm.Filter.endDate);
                fd2 = new Date(fd.getFullYear(), fd.getMonth() + 1, fd.getDate());
                vm.Filter.endDate =
                    fd.getFullYear() +
                    "-" +
                    ((fd.getMonth() + 1).toString().length == 1 ?
                        "0" + (fd.getMonth() + 1) :
                        fd.getMonth() + 1) +
                    "-" +
                    (fd.getDate().toString().length == 1 ?
                        "0" + fd.getDate() :
                        fd.getDate());
            } else {
                vm.Filter.endDate = "";
            }

            if (vm.Filter.txt1 == undefined && vm.Filter.txt1 == "") {
                vm.Filter.txt1 = 0;
            }
            if (vm.Filter.txt2 == undefined && vm.Filter.txt2 == "") {
                vm.Filter.txt2 = 0;
            }
            if (vm.Filter.txt3 == undefined && vm.Filter.txt3 == "") {
                vm.Filter.txt3 = 0;
            }

            vm.chartBind(1, 0);
        }

        function Next(type) {
            if (type == 2) {
                vm.chart2Loader = true;
                vm.trenPageNo = vm.trenPageNo + 1;
                vm.chartBind(2, vm.centerId);
            } else if (type == 3) {
                vm.chart3Loader = true;
                vm.empPageNo = vm.empPageNo + 1;
                vm.chartBind(3, vm.tranTypeId);
            }
        }

        function Prev(type) {
            if (type == 2) {
                vm.chart2Loader = true;
                vm.trenPageNo = vm.trenPageNo - 1;
                vm.chartBind(2, vm.centerId);
            } else if (type == 3) {
                vm.chart3Loader = true;
                vm.empPageNo = vm.empPageNo - 1;
                vm.chartBind(3, vm.tranTypeId);
            }
        }
    }
})();