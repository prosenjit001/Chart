(function () {
    'use strict';
    angular
        .module('ui')
        .service('ChartService', function ($http, $log, $q, $cookieStore, $rootScope, $timeout, BaseUrl) {
            return {
                GetChart: getChart
            }       

            function getChart(param) {
                return $http.post(BaseUrl + 'Chart/getList',
                    JSON.stringify(param), {
                        headers: {
                            'Content-Type': 'application/json'
                        }
                    }
                ).then(function (response) {
                    return response;
                });
            }

        })

})();