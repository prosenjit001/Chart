(function () {
    "use strict";

    angular.module("ui").controller("MainController", MainController);

    /** @ngInject */
    function MainController($scope, SharedService,$rootScope) {
        var vm = this;

        vm.selectedIndex = 0;//SharedService.retrive('tabIndex');

        $rootScope.$on("CallParentMethod", function(){
            $scope.parentmethod();
         });
 
         $scope.parentmethod = function() {
            vm.selectedIndex = 1;
         }
    }
})();