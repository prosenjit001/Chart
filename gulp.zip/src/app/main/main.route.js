(function() {
    'use strict';

    angular
        .module('ui')
        .config(routerConfig);

    /** @ngInject */
    function routerConfig($stateProvider) {
        $stateProvider
            .state('ui.main', {
                url: '/main',
                views: {
                    'Main@ui': {
                        templateUrl: "app/main/main.html",
                        controller: 'MainController',
                        controllerAs: 'vm'
                    },
                    'tab1@ui.main': {
                        templateUrl: "app/main/tab1/tab1.html",
                        controller: 'Tab1Controller',
                        controllerAs: 'vm'
                    },
                    'tab2@ui.main': {
                        templateUrl: "app/main/chart/chart.html",
                        controller: 'ChartController',
                        controllerAs: 'vm'
                    }
                }
            })
            .state('ui.Chart', {
                url: '/Chart',
                views: {
                    'Main@ui': {
                        templateUrl: "app/main/chart/chart.html",
                        controller: 'ChartController',
                        controllerAs: 'vm'
                    }
                }
            })



    }

})();