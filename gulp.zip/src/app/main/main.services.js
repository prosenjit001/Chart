(function () {
    'use strict';
    angular
        .module('ui')
        .service('MainService', function ($http,BaseUrl) {
            return {
                GetEmpList:getEmpList,
                GetCenterList:getCenterList,
                GetTranTypes:getTranTypes
            }

            function getEmpList() {
                return $http.get(BaseUrl + 'Search/getEmployees?lang=1').then(function (response) {
                    return response;
                });
            }

           function getCenterList()
           {
            return $http.get(BaseUrl + 'Center/getCenters?lang=1',1).then(function (response) {
                return response;
            });
           }

           function getTranTypes()
           {
            return $http.get(BaseUrl + 'TranType/TranTypes?lang=1').then(function (response) {
                return response;
            });
           }

        })
})();
