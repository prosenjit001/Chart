(function () {
    'use strict';

    angular
        .module('ui')
        .factory('polar', function ($rootScope, $window, $state) {
            return {
                ChartBind: function (chartType, chartName, title, flag, data, category, stack, exportIsActive, polar) {
                    var chart = Highcharts.chart({

                        title: {
                            text: ''
                        },

                        subtitle: {
                            text: ''
                        },


                        series: data

                    });

                    chart.update({
                        chart: {
                            inverted: false,
                            polar: true
                        },
                        subtitle: {
                            text: ''
                        },
                        plotOptions: {
                            column: {
                                dataLabels: {
                                    enabled: true,
                                    color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'black',
                                    useHTML: true
                                },
                                depth: 15,
                                borderRadius: 2,
                                cursor: 'pointer',
                                point: {
                                    events: {
                                        click: function () {
                                            
                                        }

                                    }
                                }

                            },
                            bar: {
                                dataLabels: {
                                    enabled: true,
                                    color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'black',
                                    useHTML: true,
                                },
                                depth: 25,
                                borderRadius: 3
                            }
                        },

                        xAxis: {
                            reversed: true,
                            categories: category,
                            labels: {
                                //rotation: -180,
                                style: {
                                    color: 'black',
                                    fontSize: '10px',
                                    fontFamily: 'Verdana, sans-serif',
                                    //fontWeight: 'bold'
                                }
                            }
                        },
                        yAxis: {
                            opposite: false,
                            title: false,
                            //gridLineWidth: 0,
                            //minorGridLineWidth: 0
                        },
                        legend: {
                            enabled: false,
                            floating: false,
                            verticalAlign: 'bottom',
                            align: 'center',
                            useHTML: true,

                        },
                        credits: {
                            enabled: false
                        }
                    });

                    return chart;
                }
            }
        })

})();