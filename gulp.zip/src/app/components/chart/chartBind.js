(function() {
    'use strict';

    angular
        .module('ui')
        .factory('chart', function($rootScope, $window, $state) {
            return {
                ChartBind: function(chartType, chartName, title, flag, data, category, stack, exportIsActive, type, index) {

                    var chartConfig = {
                        scrollbar: {
                            enabled: true
                        },
                        rangeSelector: {
                            selected: 1
                        },
                        title: {
                            text: title
                        },
                        loading: {
                            labelStyle: {
                                //backgroundImage: 'url("./assets/images/loader.gif")'
                            }
                        },

                        chart: {
                            //polar: true,
                            alignTicks: false,
                            //zoomType: 'x',
                            renderTo: chartName,
                            type: chartType,
                            //inverted: true,

                            events: {
                                drilldown: function(e) {
                                    if (!e.seriesOptions) {}
                                },
                                drillup: function(e) {

                                }
                            }
                        },
                        exporting: { enabled: exportIsActive },
                        plotOptions: {
                            area: {
                                fillColor: {
                                    linearGradient: {
                                        x1: 0,
                                        y1: 0,
                                        x2: 0,
                                        y2: 1
                                    },
                                    stops: [
                                        [0, Highcharts.getOptions().colors[0]],
                                        [1, Highcharts.Color(Highcharts.getOptions().colors[0]).setOpacity(0).get('rgba')]
                                    ]
                                },
                                marker: {
                                    radius: 2
                                },
                                lineWidth: 1,
                                states: {
                                    hover: {
                                        lineWidth: 1
                                    }
                                },
                                threshold: null
                            },

                            pie: {
                                allowPointSelect: true,
                                cursor: 'pointer',
                                dataLabels: {
                                    enabled: true,
                                    format: '<b>{point.y}</b>',
                                    style: {
                                        color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                                    }
                                },
                                showInLegend: flag
                            },
                            series: {
                                borderWidth: 0,
                                dataLabels: {
                                    enabled: true,
                                    format: '{point.y}'
                                }
                            },
                            column: {
                                stacking: stack == true ? 'normal' : '',
                                dataLabels: {
                                    enabled: true,
                                    color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'black',
                                    useHTML: true
                                },
                                depth: 15,
                                borderRadius: 2,
                                cursor: 'pointer',
                                point: {
                                    events: {
                                        click: function() {
                                            if (type == 1) {
                                                $rootScope.$broadcast('onSearch', { data: this.options, id: 2 });
                                            } else if (type == 2) {
                                                $rootScope.$broadcast('onSearch', { data: this.options, id: 3 });
                                            } else if (type == 3) {
                                                $rootScope.$broadcast('onSearch', { data: this.options, id: 4 });
                                            }
                                        }
                                    }
                                }
                            },
                            bar: {
                                dataLabels: {
                                    enabled: false,
                                    color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'black',
                                    useHTML: true
                                },
                                depth: 25,
                                borderRadius: 3,
                                cursor: 'pointer',
                                point: {
                                    events: {
                                        click: function() {
                                            console.log(this.options);
                                            if (type == 8) {
                                                debugger;
                                                $state.go('ui.List', { index: index, type: 11, name: this.options.name, id: this.options.id });
                                            } else if (type == 6) {
                                                $state.go('ui.List', { index: index, type: 9, name: this.options.name, id: this.options.id });
                                            } else if (type == 7) {
                                                $state.go('ui.List', { index: index, type: 10, name: this.options.name, id: this.options.id });
                                            } else { //else if (type == 8)
                                                //$state.go('ui.List', { index: index, type: type, name: this.options.name, id: this.options.id });
                                            }
                                        }
                                    }
                                }
                            }


                        },
                        tooltip: {
                            useHTML: true,
                            crosshairs: true,
                            shared: true,
                            headerFormat: '<small>{point.key}</small><table>',
                            pointFormat: '<tr><td style="color: {series.color}">{series.name}:{point.y} </td>',
                            footerFormat: '</table>',
                            valueDecimals: 0

                        },
                        xAxis: {
                            reversed: false,
                            categories: category,
                            labels: {
                                //rotation: -180,
                                style: {
                                    color: 'black',
                                    fontSize: '10px',
                                    fontFamily: 'Droid Arabic Kufi'
                                }
                            }
                        },
                        yAxis: {
                            opposite: false,
                            title: false
                        },
                        legend: {
                            enabled: flag,
                            floating: true,
                            verticalAlign: 'top',
                            align: 'center',
                            useHTML: false,
                            itemStyle: {
                                color: '#000000',
                                fontSize: '12px'
                            }
                            /*pie: {
                                align: 'left',
                                layout: 'vertical',
                                verticalAlign: 'top',
                                x: 40,
                                y: 0
                            }*/
                        },
                        credits: {
                            enabled: false
                        },
                        series: data,
                        drilldown: {
                            series: []
                        }
                    }



                    Highcharts.createElement('link', {
                        href: 'https://fonts.googleapis.com/css?family=Signika:400,700',
                        rel: 'stylesheet',
                        type: 'text/css'
                    }, null, document.getElementsByTagName('head')[0]);

                    // Add the background image to the container
                    Highcharts.wrap(Highcharts.Chart.prototype, 'getContainer', function(proceed) {
                        proceed.call(this);
                        //this.container.style.background = 'url(http://www.highcharts.com/samples/graphics/sand.png)';
                    });

                    Highcharts.theme = {
                        colors: ['#d3362d', '#e49307', '#5f9654', '#f1ca3a', '#4374e0', '#53a8fb', '#eeaaee',
                            '#55BF3B', '#DF5353', '#7798BF', '#aaeeee'
                        ],
                        chart: {
                            backgroundColor: null,
                            style: {
                                fontFamily: 'Droid Arabic Kufi'
                            }
                        },
                        title: {
                            style: {
                                color: 'black',
                                fontSize: '17px',
                                fontWeight: 'bold'
                            }
                        },
                        subtitle: {
                            style: {
                                color: 'black'
                            }
                        },
                        tooltip: {
                            borderWidth: 0
                        },
                        legend: {
                            itemStyle: {
                                fontWeight: 'bold',
                                fontSize: '13px'
                            }
                        },
                        xAxis: {
                            labels: {
                                style: {
                                    color: '#6e6e70'
                                }
                            }
                        },
                        yAxis: {
                            labels: {
                                style: {
                                    color: '#6e6e70'
                                }
                            }
                        },
                        plotOptions: {
                            series: {
                                shadow: true
                            },
                            candlestick: {
                                lineColor: '#404048'
                            },
                            map: {
                                shadow: false
                            }
                        },

                        // Highstock specific
                        navigator: {
                            xAxis: {
                                gridLineColor: '#D0D0D8'
                            }
                        },
                        rangeSelector: {
                            buttonTheme: {
                                fill: 'white',
                                stroke: '#C0C0C8',
                                'stroke-width': 1,
                                states: {
                                    select: {
                                        fill: '#D0D0D8'
                                    }
                                }
                            }
                        },
                        scrollbar: {
                            trackBorderColor: '#C0C0C8'
                        },

                        // General
                        background2: '#E0E0E8'

                    };
                    Highcharts.setOptions(Highcharts.theme);
                    var chart = new Highcharts.Chart(chartConfig);


                    return chart;
                }
            };
        })
})();