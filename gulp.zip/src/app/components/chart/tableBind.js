(function () {
    'use strict';

    angular
        .module('ui')
        .directive('mdtCustomCellButton', function () {
            return {
                template: '<md-button class="md-primary"><md-icon>edit</md-icon></md-button>'
            };
        })
        .factory('table', function ($rootScope, $window) {
            return {
                TableBind: function (JsonColumn, TableColumn, data, pagination, uniqueId, rowClickable) {
                    var tbl = ""; 
                    var column = TableColumn.split(',');
                    var jsoncol = JSON.stringify(JsonColumn.split(','));

                    if (pagination == true) {
                        tbl = tbl + "<mdt-table animate-sort-icon='true' paginated-rows='{isEnabled: true, rowsPerPageValues: [10,5,20,100]}' animate-sort-icon='true' ";
                        tbl = tbl + " mdt-row-paginator='vm.paginatorCallback(page, pageSize) ' ";

                        if (rowClickable) {
                            tbl = tbl + " clicked-row-callback='vm.myRowClickCallback(row) ' ";
                        }
                        tbl = tbl + " mdt-row='{\"table-row-id-key\":" + uniqueId + ", ";
                    }
                    else {
                        tbl = tbl + "<mdt-table ";
                        if (rowClickable) {
                            tbl = tbl + " clicked-row-callback='vm.myRowClickCallback(row)'";
                        }
                        tbl = tbl + "  mdt-row='{data: ";
                        tbl = tbl + JSON.stringify(data) + ", ";
                    }

                    tbl = tbl + "\"column-keys\": " + jsoncol + "} '>";
                    tbl = tbl + "<mdt-header-row>";
                    for (var i = 0; i < column.length; i++) {
                        var position = (i == 0 ? 'left' : 'right');
                        tbl = tbl + "<mdt-column column-sort='true' align-rule=" + position + ">" + column[i] + "</mdt-column>";
                    }
                    tbl = tbl + "</mdt-header-row>";
                    tbl = tbl + " <mdt-custom-cell column-key='actions'>";
                    tbl = tbl + "  <mdt-custom-cell-button></mdt-custom-cell-button>";
                    tbl = tbl + "</mdt-custom-cell></mdt-table>";
                    return tbl;
                }
            }
        })

})();