﻿(function() {
    'use strict';

    angular
        .module('ui')
        .controller('ContentController', ContentController);

    /** @ngInject */
    function ContentController($timeout, $scope, $window, $state, MainService, $mdSidenav, $filter) {
        var vm = this;

        vm.showDialog = search;
        $scope.Filter = {};
        $scope.Filter.startDate = '';
        $scope.Filter.endDate = '';
        $scope.toggleLeft = buildToggler('left');
        //$scope.toggleRight = buildToggler('right');

        vm.data = {
            cb1: false
        };
        vm.onChange = function(swState) {
            $scope.$broadcast('interval', { msg: swState == true ? 1 : 0 });
        };

        function buildToggler(componentId) {
            return function() {
                $mdSidenav(componentId).toggle();
            }
        }

        MainService.GetEmpList()
            .then(function(response) {
                response.data.unshift({ ID: 0, NameEn: "All" });
                vm.EmpList = response.data;
            })

        MainService.GetCenterList()
            .then(function(response) {
                response.data.unshift({ ID: 0, NameEn: "All" });
                vm.CenterList = response.data;
            })

        MainService.GetTranTypes()
            .then(function(response) {
                response.data.unshift({ ID: 0, NameEn: "All" });
                vm.TranTypes = response.data;
            })


        vm.closeSearch = function() {
            $mdSidenav('left').close();
        }
        $scope.LookUp = function() {
            /*  MainService.GetLabourOfficeList()
                  .then(function (response) {
                      response.data.unshift({ locode: 0, loname: "الجميع" }); //Add & move default value to top
                      $scope.Filter.labourOfficeList = response.data;

                  })*/
        }
        $scope.LookUp();
        vm.searchDashboard = function() {
            localStorage.removeItem('currentSearch');

            $scope.Filter.startDate = $scope.Filter.startDate;
            $scope.Filter.endDate = $scope.Filter.endDate;

            $scope.$broadcast('onSearch_Main', { myMsg: $scope.Filter });
            $mdSidenav('left').close();

        }

        $timeout(function() {
            //$scope.$broadcast('onLoad', { myMsg: $scope.Filter });
        }, 10);

        vm.clear = function() {
            localStorage.removeItem('currentSearch');
            $scope.Filter = {};
            $scope.LookUp();

            $scope.Filter.LabourOffice = [];
            $scope.Filter.startDate = '';
            $scope.Filter.endDate = '';

            $scope.$broadcast('onClear', { myMsg: $scope.Filter });
            $mdSidenav('left').close();
            //vm.searchDashboard();
        }

        function search(ev) {
            $mdDialog.show({
                controller: function($scope, $timeout) {
                    $scope.Filter = { LabourOffice: { locode: 0, loname: "الجميع" } }; //Default Value

                    /* MainService.GetLabourOfficeList()
                         .then(function (response) {
                             response.data.unshift({ locode: 0, loname: "الجميع" }); //Add & move default value to top
                             $scope.labourOfficeList = response.data;
                         })*/

                    vm.search = function() {
                        $scope.$broadcast('onSearch', { myMsg: $scope.Filter });
                    }
                },
                scope: $scope,
                preserveScope: true,
                templateUrl: 'app/components/dialog/filterDialog.html',
                parent: angular.element(document.body),
                targetEvent: ev,
                clickOutsideToClose: false
            });
        }



        vm.Home = function() {
            $state.go('ui.main');
        }

    }
})();