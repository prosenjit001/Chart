(function() {
  'use strict';

  angular
    .module('ui', ['ngAnimate', 'ngCookies', 'ngTouch', 'ngSanitize', 'ngMessages',
            'ngAria', 'ui.router', 'ngMaterial', 'LocalStorageModule',
            'angular-loading-bar','oitozero.ngSweetAlert','toastr','kendo.directives',
            'mdDataTable','angAccordion']);
})();
