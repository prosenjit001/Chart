(function() {
    'use strict';

    angular
        .module('ui')
        .config(routerConfig);

    /** @ngInject */
    function routerConfig($stateProvider, $urlRouterProvider) {
        $stateProvider
            .state('ui', {
                abstract: true,
                templateUrl: "app/components/template/content.html",
                controller: "ContentController as vm"
            })

        $urlRouterProvider.otherwise('/login');
    }

})();