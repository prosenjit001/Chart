(function () {
    'use strict';
    angular
        .module('UI')
        .service('LoginService', ['$state', '$http', '$log', '$q', '$cookieStore', '$rootScope', '$timeout', 'BaseUrl', 'localStorageService', function ($state, $http, $log, $q, $cookieStore, $rootScope, $timeout, BaseUrl, localStorageService) {
            return {
                ValidateDomainUser: validateDomainUser,
                LogOut: logOut
            };

            function validateDomainUser(loginInfo) {
                var data = "grant_type=password&username=" +
                    loginInfo.userName + "&password=" + encodeURIComponent(loginInfo.password);


                return $http.post(BaseUrl + 'token', data, {
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
                }).then(function (response) {

                    localStorageService.remove('chartAuthorizationData');
                    localStorageService.set('chartAuthorizationData', { token: response.data.access_token, userName: loginInfo.userName });


                    response.data.isAuth = true;
                    response.data.userName = loginInfo.userName;

                    return response;

                });
            }

            function logOut() {
                localStorageService.remove('chartAuthorizationData');
                $state.go("login");
            }

            

        }])
})();