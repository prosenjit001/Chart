(function() {
    'use strict';

    angular
        .module('ui')
        .controller('LoginController', LoginController)

    function LoginController($scope, $timeout, $state) {
        var vm = this;

        vm.redirectToDashboard = function() {
            $state.go('ui.main');
        }
    }

})();